package com.myaiassistant.app.model

enum class AppLanguage(val code: String, val displayName: String, val isRtl: Boolean) {
    AFGHAN_UZBEK("uz-AF", "اوزبیکچه", true),
    DARI("fa-AF", "دری", true),
    ENGLISH("en", "English", false),
    PASHTO("ps-AF", "پښتو", true)
}

enum class AiTool(
    val id: String,
    val labelEn: String,
    val labelFa: String,
    val labelUz: String,
    val labelPs: String
) {
    QA("qa", "Answer Questions", "پاسخ به سوالات", "سوال‌لرگه جواب", "پوښتنو ته ځوابونه"),
    WRITE("write", "Write Articles & Letters", "نوشتن مقاله و نامه", "مقاله و خط یازیش", "مقاله او لیک لیکل"),
    TRANSLATE("translate", "Translate Languages", "ترجمه میان زبان‌ها", "تیل‌لر ترجمه‌سی", "د ژبو ژباړه"),
    SUMMARIZE("summarize", "Summarize Text", "خلاصه‌سازی متن", "متن خلاصه‌سی", "متن لنډول"),
    EXPLAIN("explain", "Explain Subjects", "توضیح مضامین درسی", "درس تۆشۆنتیریش", "درسي مضامین تشریح"),
    IDEAS("ideas", "Generate Ideas", "تولید ایده", "ایده یراتیش", "نوي نظرونه جوړول"),
    GRAMMAR("grammar", "Correct Grammar", "اصلاح دستور زبان", "گرامر تۆزه‌تیش", "ګرامر سمول"),
    MATH("math", "Help with Math", "کمک در ریاضی", "ریاضی یاردمی", "په ریاضي کې مرسته");

    fun label(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> labelEn
        AppLanguage.DARI -> labelFa
        AppLanguage.AFGHAN_UZBEK -> labelUz
        AppLanguage.PASHTO -> labelPs
    }
}

enum class AppScreen {
    WELCOME,
    CHAT,
    HISTORY,
    SETTINGS,
    ABOUT
}

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val role: String, // "user" | "assistant"
    val content: String,
    val createdAt: Long
)

data class Conversation(
    val id: String,
    val title: String,
    val toolId: String,
    val languageCode: String,
    val updatedAt: Long,
    val messages: List<ChatMessage> = emptyList()
)

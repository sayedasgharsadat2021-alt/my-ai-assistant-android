package com.myaiassistant.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.myaiassistant.app.model.AppLanguage
import com.myaiassistant.app.model.AppScreen
import com.myaiassistant.app.ui.screens.*
import com.myaiassistant.app.ui.theme.MyAiAssistantTheme
import com.myaiassistant.app.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val language by viewModel.language.collectAsStateWithLifecycle()
            val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
            val conversations by viewModel.conversations.collectAsStateWithLifecycle()
            val activeMessages by viewModel.activeMessages.collectAsStateWithLifecycle()
            val selectedTool by viewModel.selectedTool.collectAsStateWithLifecycle()
            val isStreaming by viewModel.isStreaming.collectAsStateWithLifecycle()
            val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

            val layoutDirection = if (language.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            val navHome = when (language) {
                AppLanguage.ENGLISH -> "Home"
                AppLanguage.DARI -> "خانه"
                AppLanguage.AFGHAN_UZBEK -> "باش صحیفه"
                AppLanguage.PASHTO -> "کور"
            }
            val navChat = when (language) {
                AppLanguage.ENGLISH -> "Chat"
                AppLanguage.DARI -> "گفتگو"
                AppLanguage.AFGHAN_UZBEK -> "سحبت"
                AppLanguage.PASHTO -> "خبرې"
            }
            val navHistory = when (language) {
                AppLanguage.ENGLISH -> "History"
                AppLanguage.DARI -> "تاریخچه"
                AppLanguage.AFGHAN_UZBEK -> "تاریخچه"
                AppLanguage.PASHTO -> "تاریخچه"
            }
            val navSettings = when (language) {
                AppLanguage.ENGLISH -> "Settings"
                AppLanguage.DARI -> "تنظیمات"
                AppLanguage.AFGHAN_UZBEK -> "تنظیمات"
                AppLanguage.PASHTO -> "تنظیمات"
            }
            val navAbout = when (language) {
                AppLanguage.ENGLISH -> "About"
                AppLanguage.DARI -> "درباره"
                AppLanguage.AFGHAN_UZBEK -> "حقیده"
                AppLanguage.PASHTO -> "په اړه"
            }

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MyAiAssistantTheme(darkTheme = isDarkMode) {
                    Scaffold(
                        topBar = {
                            TopAppBar(
                                title = { Text("My AI Assistant") },
                                actions = {
                                    IconButton(onClick = { viewModel.startNewConversation() }) {
                                        Icon(Icons.Default.Add, contentDescription = "New Chat")
                                    }
                                }
                            )
                        },
                        bottomBar = {
                            NavigationBar {
                                NavigationBarItem(
                                    selected = activeScreen == AppScreen.WELCOME,
                                    onClick = { viewModel.navigate(AppScreen.WELCOME) },
                                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                                    label = { Text(navHome) }
                                )
                                NavigationBarItem(
                                    selected = activeScreen == AppScreen.CHAT,
                                    onClick = { viewModel.navigate(AppScreen.CHAT) },
                                    icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                                    label = { Text(navChat) }
                                )
                                NavigationBarItem(
                                    selected = activeScreen == AppScreen.HISTORY,
                                    onClick = { viewModel.navigate(AppScreen.HISTORY) },
                                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                                    label = { Text(navHistory) }
                                )
                                NavigationBarItem(
                                    selected = activeScreen == AppScreen.SETTINGS,
                                    onClick = { viewModel.navigate(AppScreen.SETTINGS) },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                    label = { Text(navSettings) }
                                )
                                NavigationBarItem(
                                    selected = activeScreen == AppScreen.ABOUT,
                                    onClick = { viewModel.navigate(AppScreen.ABOUT) },
                                    icon = { Icon(Icons.Default.Info, contentDescription = null) },
                                    label = { Text(navAbout) }
                                )
                            }
                        }
                    ) { innerPadding ->
                        val modifier = Modifier.padding(innerPadding)
                        when (activeScreen) {
                            AppScreen.WELCOME -> WelcomeScreen(
                                language = language,
                                selectedTool = selectedTool,
                                onSelectTool = viewModel::selectTool,
                                onSendPrompt = viewModel::sendMessage,
                                modifier = modifier
                            )
                            AppScreen.CHAT -> ChatScreen(
                                language = language,
                                messages = activeMessages,
                                isStreaming = isStreaming,
                                errorMessage = errorMessage,
                                onSend = viewModel::sendMessage,
                                onCancel = viewModel::cancelGeneration,
                                onRegenerate = viewModel::regenerateLastResponse,
                                modifier = modifier
                            )
                            AppScreen.HISTORY -> HistoryScreen(
                                language = language,
                                conversations = conversations,
                                onOpen = viewModel::openConversation,
                                onRename = viewModel::renameConversation,
                                onDelete = viewModel::deleteConversation,
                                modifier = modifier
                            )
                            AppScreen.SETTINGS -> SettingsScreen(
                                isDarkMode = isDarkMode,
                                language = language,
                                onToggleDarkMode = viewModel::setDarkMode,
                                onSelectLanguage = viewModel::setLanguage,
                                onClearHistory = viewModel::clearAllConversations,
                                modifier = modifier
                            )
                            AppScreen.ABOUT -> AboutScreen(language = language, modifier = modifier)
                        }
                    }
                }
            }
        }
    }
}

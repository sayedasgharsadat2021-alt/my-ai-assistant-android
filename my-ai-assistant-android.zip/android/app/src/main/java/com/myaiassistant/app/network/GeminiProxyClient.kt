package com.myaiassistant.app.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.myaiassistant.app.BuildConfig
import com.myaiassistant.app.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class OfflineException : IOException("Internet connection unavailable")

class GeminiProxyClient(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()

    fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun streamChat(
        messages: List<ChatMessage>,
        languageCode: String,
        toolId: String
    ): Flow<String> = flow {
        if (!isNetworkAvailable()) {
            throw OfflineException()
        }

        val payload = JSONObject().apply {
            put("language", languageCode)
            put("toolId", toolId)
            put("stream", true)
            put("messages", JSONArray().apply {
                messages.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
            })
        }

        val request = Request.Builder()
            .url("${BuildConfig.API_BASE_URL}/api/chat")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Server returned HTTP ${response.code}")
            }
            val source = response.body?.source() ?: throw IOException("Empty response body")
            val accumulated = StringBuilder()

            while (!source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                if (line.startsWith("data: ")) {
                    val jsonStr = line.removePrefix("data: ").trim()
                    if (jsonStr.isEmpty()) continue
                    val event = JSONObject(jsonStr)
                    when (event.optString("type")) {
                        "chunk" -> {
                            val chunk = event.optString("text", "")
                            if (chunk.isNotEmpty()) {
                                accumulated.append(chunk)
                                emit(accumulated.toString())
                            }
                        }
                        "error" -> {
                            throw IOException(event.optString("message", "AI service error"))
                        }
                    }
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}

package com.myaiassistant.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.myaiassistant.app.data.AppPreferences
import com.myaiassistant.app.data.AssistantDatabase
import com.myaiassistant.app.data.ConversationEntity
import com.myaiassistant.app.data.MessageEntity
import com.myaiassistant.app.model.AiTool
import com.myaiassistant.app.model.AppLanguage
import com.myaiassistant.app.model.AppScreen
import com.myaiassistant.app.model.ChatMessage
import com.myaiassistant.app.model.Conversation
import com.myaiassistant.app.network.GeminiProxyClient
import com.myaiassistant.app.network.OfflineException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AssistantDatabase.getInstance(application).dao()
    private val prefs = AppPreferences(application)
    private val apiClient = GeminiProxyClient(application)

    val isDarkMode: StateFlow<Boolean> = prefs.isDarkMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val language: StateFlow<AppLanguage> = prefs.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.ENGLISH)

    val conversations: StateFlow<List<Conversation>> = dao.observeConversations()
        .map { list ->
            list.map {
                Conversation(
                    id = it.id,
                    title = it.title,
                    toolId = it.toolId,
                    languageCode = it.languageCode,
                    updatedAt = it.updatedAt
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val activeMessages: StateFlow<List<ChatMessage>> = _activeConversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else dao.observeMessages(id).map { list ->
                list.map { ChatMessage(it.id, it.conversationId, it.role, it.content, it.createdAt) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeScreen = MutableStateFlow(AppScreen.WELCOME)
    val activeScreen: StateFlow<AppScreen> = _activeScreen.asStateFlow()

    private val _selectedTool = MutableStateFlow(AiTool.QA)
    val selectedTool: StateFlow<AiTool> = _selectedTool.asStateFlow()

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var streamJob: Job? = null

    fun navigate(screen: AppScreen) {
        _errorMessage.value = null
        _activeScreen.value = screen
    }

    fun selectTool(tool: AiTool) {
        _selectedTool.value = tool
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { prefs.setDarkMode(enabled) }
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch { prefs.setLanguage(lang) }
    }

    fun startNewConversation() {
        streamJob?.cancel()
        _isStreaming.value = false
        _errorMessage.value = null
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            dao.upsertConversation(
                ConversationEntity(
                    id = id,
                    title = "New Conversation",
                    toolId = _selectedTool.value.id,
                    languageCode = language.value.code,
                    updatedAt = now
                )
            )
            _activeConversationId.value = id
            _activeScreen.value = AppScreen.CHAT
        }
    }

    fun openConversation(id: String) {
        streamJob?.cancel()
        _isStreaming.value = false
        _errorMessage.value = null
        _activeConversationId.value = id
        _activeScreen.value = AppScreen.CHAT
    }

    fun renameConversation(id: String, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            dao.renameConversation(id, trimmed, System.currentTimeMillis())
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            dao.deleteConversation(id)
            if (_activeConversationId.value == id) {
                _activeConversationId.value = null
                _activeScreen.value = AppScreen.WELCOME
            }
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            dao.clearAllConversations()
            _activeConversationId.value = null
            _activeScreen.value = AppScreen.WELCOME
        }
    }

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _isStreaming.value) return

        viewModelScope.launch {
            val now = System.currentTimeMillis()
            var convId = _activeConversationId.value
            val currentMessages = activeMessages.value

            if (convId == null || _activeScreen.value == AppScreen.WELCOME) {
                convId = UUID.randomUUID().toString()
                val title = if (trimmed.length <= 44) trimmed else trimmed.take(41) + "..."
                dao.upsertConversation(
                    ConversationEntity(
                        id = convId,
                        title = title,
                        toolId = _selectedTool.value.id,
                        languageCode = language.value.code,
                        updatedAt = now
                    )
                )
                _activeConversationId.value = convId
                _activeScreen.value = AppScreen.CHAT
            } else if (currentMessages.isEmpty()) {
                val title = if (trimmed.length <= 44) trimmed else trimmed.take(41) + "..."
                dao.renameConversation(convId, title, now)
            }

            val userMsg = MessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = convId,
                role = "user",
                content = trimmed,
                createdAt = now
            )
            dao.upsertMessage(userMsg)

            val historyForApi = currentMessages + ChatMessage(
                userMsg.id, userMsg.conversationId, userMsg.role, userMsg.content, userMsg.createdAt
            )
            streamAssistantReply(convId, historyForApi)
        }
    }

    fun regenerateLastResponse() {
        val convId = _activeConversationId.value ?: return
        val messages = activeMessages.value
        val lastUserIdx = messages.indexOfLast { it.role == "user" }
        if (lastUserIdx == -1 || _isStreaming.value) return

        viewModelScope.launch {
            val cutoff = messages[lastUserIdx].createdAt
            dao.deleteMessagesAfter(convId, cutoff)
            streamAssistantReply(convId, messages.subList(0, lastUserIdx + 1))
        }
    }

    fun cancelGeneration() {
        streamJob?.cancel()
        streamJob = null
        _isStreaming.value = false
    }

    private fun streamAssistantReply(conversationId: String, contextMessages: List<ChatMessage>) {
        streamJob?.cancel()
        val assistantMsgId = UUID.randomUUID().toString()
        val createdAt = System.currentTimeMillis()

        _errorMessage.value = null
        _isStreaming.value = true

        streamJob = viewModelScope.launch {
            dao.upsertMessage(
                MessageEntity(
                    id = assistantMsgId,
                    conversationId = conversationId,
                    role = "assistant",
                    content = "",
                    createdAt = createdAt
                )
            )

            try {
                apiClient.streamChat(
                    messages = contextMessages,
                    languageCode = language.value.code,
                    toolId = _selectedTool.value.id
                ).catch { err ->
                    _errorMessage.value = when (err) {
                        is OfflineException -> "No internet connection. Please reconnect and retry."
                        is java.net.SocketTimeoutException -> "The AI took too long to respond. Please retry."
                        else -> err.message ?: "Failed to generate response."
                    }
                }.collect { accumulated ->
                    dao.upsertMessage(
                        MessageEntity(
                            id = assistantMsgId,
                            conversationId = conversationId,
                            role = "assistant",
                            content = accumulated,
                            createdAt = createdAt
                        )
                    )
                }
            } finally {
                _isStreaming.value = false
            }
        }
    }
}

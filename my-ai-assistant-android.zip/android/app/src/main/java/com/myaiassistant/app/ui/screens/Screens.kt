package com.myaiassistant.app.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.myaiassistant.app.model.*
import kotlinx.coroutines.delay

@Composable
fun WelcomeScreen(
    language: AppLanguage,
    selectedTool: AiTool,
    onSelectTool: (AiTool) -> Unit,
    onSendPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var draft by remember { mutableStateOf("") }

    val inputPlaceholder = when (language) {
        AppLanguage.ENGLISH -> "Message My AI Assistant..."
        AppLanguage.DARI -> "پیام خود را بنویسید..."
        AppLanguage.AFGHAN_UZBEK -> "سوالینگیزنی یازینگ..."
        AppLanguage.PASHTO -> "خپل پیغام ولیکئ..."
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = when (language) {
                    AppLanguage.ENGLISH -> "How can I help you today?"
                    AppLanguage.DARI -> "امروز چگونه می‌توانم کمکتان کنم؟"
                    AppLanguage.AFGHAN_UZBEK -> "بوگون سیزگه قنده‌ی یاردم بېره آله‌من؟"
                    AppLanguage.PASHTO -> "نن درسره څنګه مرسته کولی شم؟"
                },
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(AiTool.entries) { tool ->
                    val isSelected = tool == selectedTool
                    ElevatedCard(
                        onClick = { onSelectTool(tool) },
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text(
                            text = tool.label(language),
                            modifier = Modifier.padding(14.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(inputPlaceholder) },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = {
                    if (draft.isNotBlank()) {
                        onSendPrompt(draft)
                        draft = ""
                    }
                }
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
private fun AiProcessingIndicator(
    language: AppLanguage,
    onCancel: () -> Unit
) {
    val messages = when (language) {
        AppLanguage.ENGLISH -> listOf(
            "Analyzing your question...",
            "Preparing your answer...",
            "Generating response..."
        )
        AppLanguage.DARI -> listOf(
            "در حال تحلیل سوال شما...",
            "در حال آماده‌سازی پاسخ...",
            "در حال تولید پاسخ..."
        )
        AppLanguage.AFGHAN_UZBEK -> listOf(
            "سوالینگیز تحلیل قیلینماقده...",
            "جواب تیارلنه‌یاپتی...",
            "جواب یراتیلماقده..."
        )
        AppLanguage.PASHTO -> listOf(
            "ستاسو پوښتنه ارزول کېږي...",
            "ستاسو ځواب چمتو کېږي...",
            "ځواب جوړېږي..."
        )
    }

    val cancelLabel = when (language) {
        AppLanguage.ENGLISH -> "Cancel"
        AppLanguage.DARI -> "لغو"
        AppLanguage.AFGHAN_UZBEK -> "بیکار قیلیش"
        AppLanguage.PASHTO -> "لغوه کول"
    }

    var stageIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(language) {
        stageIndex = 0
        while (true) {
            delay(1500)
            stageIndex = (stageIndex + 1) % messages.size
        }
    }

    val transition = rememberInfiniteTransition(label = "processing")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing)),
        label = "iconRotation"
    )
    val dot1 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "dot1"
    )
    val dot2 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(450, delayMillis = 150), RepeatMode.Reverse),
        label = "dot2"
    )
    val dot3 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(450, delayMillis = 300), RepeatMode.Reverse),
        label = "dot3"
    )

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp).rotate(rotation)
            )
            Text(
                text = messages[stageIndex],
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f, fill = false)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).alpha(dot1).background(MaterialTheme.colorScheme.primary, CircleShape))
                Box(Modifier.size(6.dp).alpha(dot2).background(MaterialTheme.colorScheme.primary, CircleShape))
                Box(Modifier.size(6.dp).alpha(dot3).background(MaterialTheme.colorScheme.primary, CircleShape))
            }
            TextButton(
                onClick = onCancel,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(cancelLabel, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun ChatScreen(
    language: AppLanguage,
    messages: List<ChatMessage>,
    isStreaming: Boolean,
    errorMessage: String?,
    onSend: (String) -> Unit,
    onCancel: () -> Unit,
    onRegenerate: () -> Unit,
    modifier: Modifier = Modifier
) {
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current

    val copyLabel = when (language) {
        AppLanguage.ENGLISH -> "Copy"
        AppLanguage.DARI -> "کاپی"
        AppLanguage.AFGHAN_UZBEK -> "کپی"
        AppLanguage.PASHTO -> "کاپي"
    }
    val regenerateLabel = when (language) {
        AppLanguage.ENGLISH -> "Regenerate"
        AppLanguage.DARI -> "تولید مجدد"
        AppLanguage.AFGHAN_UZBEK -> "قیته یراتیش"
        AppLanguage.PASHTO -> "بیا جوړول"
    }
    val retryLabel = when (language) {
        AppLanguage.ENGLISH -> "Retry"
        AppLanguage.DARI -> "تلاش مجدد"
        AppLanguage.AFGHAN_UZBEK -> "قیته اورینیش"
        AppLanguage.PASHTO -> "بیا هڅه"
    }
    val inputPlaceholder = when (language) {
        AppLanguage.ENGLISH -> "Message My AI Assistant..."
        AppLanguage.DARI -> "پیام خود را بنویسید..."
        AppLanguage.AFGHAN_UZBEK -> "سوالینگیزنی یازینگ..."
        AppLanguage.PASHTO -> "خپل پیغام ولیکئ..."
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty() && !listState.isScrollInProgress) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                val isCurrentStreaming = isStreaming && msg.id == messages.lastOrNull()?.id && !isUser

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    if (!isUser && msg.content.isEmpty() && isStreaming) {
                        AiProcessingIndicator(language = language, onCancel = onCancel)
                    } else {
                        Surface(
                            color = if (isUser) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = msg.content,
                                color = if (isUser) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (!isUser && msg.content.isNotEmpty() && !isCurrentStreaming) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { clipboard.setText(AnnotatedString(msg.content)) }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(copyLabel)
                            }
                            TextButton(onClick = onRegenerate, enabled = !isStreaming) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(regenerateLabel)
                            }
                        }
                    }
                }
            }
        }

        if (errorMessage != null) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.weight(1f))
                    TextButton(onClick = onRegenerate) { Text(retryLabel) }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(inputPlaceholder) },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            if (isStreaming) {
                FilledIconButton(
                    onClick = onCancel,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    )
                ) {
                    Icon(Icons.Default.Stop, contentDescription = "Cancel")
                }
            } else {
                FilledIconButton(
                    onClick = {
                        if (draft.isNotBlank()) {
                            onSend(draft)
                            draft = ""
                        }
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(
    language: AppLanguage,
    conversations: List<Conversation>,
    onOpen: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var renamingId by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }

    val saveLabel = when (language) {
        AppLanguage.ENGLISH -> "Save"
        AppLanguage.DARI -> "ذخیره"
        AppLanguage.AFGHAN_UZBEK -> "سقلش"
        AppLanguage.PASHTO -> "خوندي کول"
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(conversations, key = { it.id }) { conv ->
            Card(onClick = { onOpen(conv.id) }) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                    if (renamingId == conv.id) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = renameText,
                                onValueChange = { renameText = it },
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                onRename(conv.id, renameText)
                                renamingId = null
                            }) { Text(saveLabel) }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(conv.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                renamingId = conv.id
                                renameText = conv.title
                            }) {
                                Icon(Icons.Default.Edit, contentDescription = "Rename")
                            }
                            IconButton(onClick = { onDelete(conv.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    isDarkMode: Boolean,
    language: AppLanguage,
    onToggleDarkMode: (Boolean) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val themeTitle = when (language) {
        AppLanguage.ENGLISH -> "Dark Theme"
        AppLanguage.DARI -> "تم تاریک"
        AppLanguage.AFGHAN_UZBEK -> "قارانغو تېمه"
        AppLanguage.PASHTO -> "تیاره بڼه"
    }
    val languageTitle = when (language) {
        AppLanguage.ENGLISH -> "Language"
        AppLanguage.DARI -> "زبان"
        AppLanguage.AFGHAN_UZBEK -> "تیل"
        AppLanguage.PASHTO -> "ژبه"
    }
    val clearLabel = when (language) {
        AppLanguage.ENGLISH -> "Clear All Conversations"
        AppLanguage.DARI -> "پاک کردن همه گفتگوها"
        AppLanguage.AFGHAN_UZBEK -> "برچه سحبت‌لرنی اۉچیریش"
        AppLanguage.PASHTO -> "ټولې خبرې پاکول"
    }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(themeTitle, style = MaterialTheme.typography.titleMedium)
            Switch(checked = isDarkMode, onCheckedChange = onToggleDarkMode)
        }

        Text(languageTitle, style = MaterialTheme.typography.titleMedium)
        AppLanguage.entries.forEach { lang ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = language == lang,
                    onClick = { onSelectLanguage(lang) }
                )
                Text(lang.displayName)
            }
        }

        OutlinedButton(onClick = onClearHistory) {
            Text(clearLabel)
        }
    }
}

@Composable
fun AboutScreen(
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val description = when (language) {
        AppLanguage.ENGLISH ->
            "Multilingual AI assistant supporting Afghan Uzbek (RTL), Dari (RTL), English (LTR), and Pashto (RTL). " +
                "Powered by Gemini streaming via a secure server-side proxy with local Room & DataStore persistence."
        AppLanguage.DARI ->
            "دستیار هوش مصنوعی چندزبانه با پشتیبانی از اوزبیکچه (راست‌به‌چپ)، دری (راست‌به‌چپ)، انگلیسی (چپ‌به‌راست) و پشتو (راست‌به‌چپ) با پاسخ‌های زنده و تاریخچه محلی."
        AppLanguage.AFGHAN_UZBEK ->
            "اوزبیکچه، دری، انگلیسی و پشتو تیل‌لرینی قۉللب-قوّتلاوچی تیزکر سونعی هوش یاردمچیسی، جانلی جواب‌لر و محلی تاریخچه بیلن."
        AppLanguage.PASHTO ->
            "څو ژبنی د مصنوعي ځيرکتيا مرستندوی چې ازبکي، دري، انګليسي او پښتو ملاتړ کوي او ژوندي ځوابونه او ځايي تاريخچه برابروي."
    }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("My AI Assistant", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(description)
    }
}

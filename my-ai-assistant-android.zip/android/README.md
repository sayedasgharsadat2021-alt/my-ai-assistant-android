# My AI Assistant — Native Android Project

Kotlin + Jetpack Compose Android client connecting to the secure Gemini backend proxy (`BuildConfig.API_BASE_URL`) with no API keys embedded in the APK.

## Features Included
- **Four Languages & RTL/LTR**: Afghan Uzbek (`uz-AF`, RTL), Dari (`fa-AF`, RTL), English (`en`, LTR), Pashto (`ps-AF`, RTL).
- **Live SSE Streaming & Cancellation**: Progressive streaming replies, animated processing indicator with 3 cycling localized messages, and user cancellation (`Cancel` / `Stop`).
- **Local Persistence**: Room database (`conversations`, `messages`) + DataStore preferences (theme & language).
- **Branding & Release Config**: Adaptive launcher icon (`ic_launcher`), Android 12+ SplashScreen (`Theme.MyAIAssistant.Splash`), and release signing config in `app/build.gradle.kts`.

## Build & Sign Release APK
1. Open this `android/` folder in **Android Studio** (JDK 17, Android SDK 35), or configure Gradle 8.9+.
2. Generate a release keystore (once):
   ```bash
   keytool -genkey -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias myaiassistant
   ```
3. Copy `keystore.properties.example` to `keystore.properties` and fill in your keystore credentials (or export `ANDROID_KEYSTORE_PATH`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEYSTORE_ALIAS`, `ANDROID_KEYSTORE_PASSWORD`).
4. Build the signed release APK:
   ```bash
   gradle assembleRelease
   ```
   Output APK: `app/build/outputs/apk/release/app-release.apk`.
